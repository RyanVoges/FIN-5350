## Reflection on HW1 Part II

This assignment went smoothly for both of us. There are two things that I didn't fully understand; first, I need a better understanding of the 'f' inside of the print function; second, I don't completely understand the format of the digit formatter. I really like our team. Please don't split us up.