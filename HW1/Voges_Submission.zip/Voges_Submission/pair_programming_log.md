9.15.20 Tu, 14:00 - 14:30 Jack Baldwin and Ryan Voges, 0.5 hours
Summary: Worked on getting access to github and completed assignment 1 part 2
Driver order and time length
Ryan Voges, 15 minutes
Jack Baldwin, 15 minutes 

