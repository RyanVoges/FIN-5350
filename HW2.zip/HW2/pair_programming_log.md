9.15.20 Tu, 14:00 - 14:30 Jack Baldwin and Ryan Voges
Summary: Worked on getting access to github and completed assignment 1 section 2
Driver order and time length
Ryan Voges, 15 minutes,
Jack Baldwin, 15 minutes 

10.07.20 Wed, 15:00 - 16:20 Jack Baldwin and Ryan Voges
Summary: Looked over assignment 2 and began to answer question 2
Driver order and time length
Jack Baldwin, 30 minutes 
Ryan Voges, 30 minutes,

10.10.20 Sat, 18:00 - 19:20 Jack Baldwin and Ryan Voges
Summary: Went over Hmwrk 2 question 1 answer, redid question 2 based on question 1 process.
Driver order and time length
Ryan Voges, 30 minutes 
Jack Baldwin, 50 minutes

10.12.20 Sat, 15:00 - 16:15 Jack Baldwin and Ryan Voges
Summary: Worked on HMWK 2 Question 3
Driver order and time length
Jack Baldwin, 25 Minutes
Ryan Voges, 50 minutes

10.19.20 Sat, 14:00 - 16:00 Jack Baldwin and Ryan Voges
Summary: Worked on HMWK 2 Question 4
Driver order and time length
Jack Baldwin, 60 Minutes
Ryan Voges, 60 minutes

10.24.20 Sat, 15:00 - 17:00 Jack Baldwin and Ryan Voges
Summary: Worked on HMWK 2 addendum questions
Driver order and time length
Ryan Voges, 60 Minutes
Jack Baldwin, 60 Minutes 
